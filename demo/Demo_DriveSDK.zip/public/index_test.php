<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>DrEdit</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

  </head>
  
  
  <body>
      <h1>VAMOSSSS</h1>
      <pre>
          <?=var_dump($client);?>
      </pre>
      <pre>
          <?=var_dump($user);?>
      </pre>
  </body>
</html>
