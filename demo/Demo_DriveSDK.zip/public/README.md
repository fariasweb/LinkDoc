Front-end component of the [DrEdit](http://developers.google.com/drive/examples), a sample text editor 
application uses that Google Drive as it's storage system. The application has feature equivalent implementations
in Java, Python, PHP, .NET, Ruby, Android and iOS. The main repo is on
[googledrive/dredit](https://github.com/googledrive/dredit).
