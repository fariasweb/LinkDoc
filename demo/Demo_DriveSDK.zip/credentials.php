<?php

// obtain these credentials from https://code.google.com/apis/console
const CLIENT_ID = '340793550758-fejo769dj4stdmjbsfi66j4l3462esl5.apps.googleusercontent.com';
const CLIENT_SECRET = 'J1A4jFx993ENxgitIHYT1oKO';
const REDIRECT_URI = 'http://linkdoc.farias.com';
